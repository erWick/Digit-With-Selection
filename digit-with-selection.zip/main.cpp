/*
Erik Hall 101115254
*/
#include <stdio.h>
#include <iostream>
using namespace std;

int main()
{
    int input;
    cout << "Enter your number (0 < n < 10000): ";
    cin >> input;

    if (input <= 10000 || input >= 0)
    {
        cout << "Input must be greater than 0 and less than 10000";
        return 0;
    }

    if (input < 10 && input > 0)
    {
        cout << "Input has 1 digit";
    }
    else
    {
        input = input/10;
        if (input < 10 && input > 0)
        {
            cout << "Input has 2 digits";
        }
        else
        {
            input = input/10;
            if (input < 10 && input > 0)
            {
                cout << "Input has 3 digits";
            }
            else
            {
                input = input/10;
                if (input < 10 && input > 0)
                {
                    cout << "Input has 4 digits";
                }
            }
        }
    }
    
    return 0;
}
